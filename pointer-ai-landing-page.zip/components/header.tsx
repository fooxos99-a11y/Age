"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/components/language-provider"

export function Header() {
  const { language, toggleLanguage } = useLanguage()

  const navItems =
    language === "ar"
      ? [
          { name: "أفضل اللاعبين", href: "/players" },
          { name: "البطولات", href: "#pricing-section" },
          { name: "الفيديوهات", href: "#testimonials-section" },
          { name: "ديسكورد", href: "#discord-section" },
        ]
      : [
          { name: "Best Players", href: "/players" },
          { name: "Tournaments", href: "#pricing-section" },
          { name: "Videos", href: "#testimonials-section" },
          { name: "Discord", href: "#discord-section" },
        ]

  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    // If it's a route (doesn't start with #), let Next.js handle it
    if (!href.startsWith("#")) {
      return
    }

    e.preventDefault()
    const targetId = href.substring(1)
    const targetElement = document.getElementById(targetId)
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <header className="w-full py-4 px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link href="/" className="text-foreground text-xl font-semibold hover:opacity-80 transition-opacity">
            Age of arabia
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-2 absolute left-1/2 -translate-x-1/2">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              onClick={(e) => handleScroll(e, item.href)}
              className="text-[#888888] hover:text-foreground px-4 py-2 rounded-full font-medium transition-colors"
            >
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <Button
            onClick={toggleLanguage}
            className="bg-secondary text-secondary-foreground hover:bg-secondary/90 px-6 py-2 rounded-full font-medium shadow-sm hidden md:block"
          >
            {language === "ar" ? "AR" : "EN"}
          </Button>
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="text-foreground">
                <Menu className="h-7 w-7" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="bg-background border-t border-border text-foreground">
              <SheetHeader>
                <SheetTitle className="text-left text-xl font-semibold text-foreground">
                  {language === "ar" ? "القائمة" : "Navigation"}
                </SheetTitle>
              </SheetHeader>
              <nav className="flex flex-col gap-4 mt-6">
                {navItems.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={(e) => handleScroll(e, item.href)}
                    className="text-[#888888] hover:text-foreground justify-start text-lg py-2"
                  >
                    {item.name}
                  </Link>
                ))}
                <Button
                  onClick={toggleLanguage}
                  className="bg-secondary text-secondary-foreground hover:bg-secondary/90 px-6 py-2 rounded-full font-medium shadow-sm mt-4"
                >
                  {language === "ar" ? "AR" : "EN"}
                </Button>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
